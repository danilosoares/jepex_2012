require 'test_helper'

class BuscaHelperTest < ActionView::TestCase
end
