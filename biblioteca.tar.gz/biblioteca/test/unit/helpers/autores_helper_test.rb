require 'test_helper'

class AutoresHelperTest < ActionView::TestCase
end
