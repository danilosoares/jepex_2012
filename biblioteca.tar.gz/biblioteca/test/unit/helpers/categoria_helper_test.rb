require 'test_helper'

class CategoriaHelperTest < ActionView::TestCase
end
