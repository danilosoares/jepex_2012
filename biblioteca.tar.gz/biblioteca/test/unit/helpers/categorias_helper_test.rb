require 'test_helper'

class CategoriasHelperTest < ActionView::TestCase
end
