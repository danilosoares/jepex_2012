require 'test_helper'

class EditorasHelperTest < ActionView::TestCase
end
