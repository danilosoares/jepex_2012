require 'test_helper'

class CategoriaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
