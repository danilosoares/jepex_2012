require 'test_helper'

class AutorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
