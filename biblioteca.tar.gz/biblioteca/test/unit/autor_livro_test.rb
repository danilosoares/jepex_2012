require 'test_helper'

class AutorLivroTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
