require 'test_helper'

class BuscaControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
